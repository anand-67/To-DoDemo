//
//  TasksListVC.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
//

import UIKit

class TasksListVC: UIViewController {

    
    //MARK: UITableView
    @IBOutlet weak var tblViewTasksList: UITableView!
    
    //MARK: UIButton
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var btnAddTasks: UIButton!
    @IBOutlet weak var btnLogout: UIButton!
    
    //MARK: Variables
    var user : User?
    var tasks : [Task] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if let username = UserDefaults.standard.value(forKey: "username") , let user =  UserManager.shared.fetchUser(username: username as! String){
            self.user = user
            let allTasks = TaskManager.shared.fetchAllTasks(userid: user.id ?? "")
            if allTasks.count > 0 {
                self.tasks = allTasks
            }
        }
        UIView.animate(withDuration: 0.3) {
            self.tblViewTasksList.reloadData()
        }
       
    }
    
    
    //MARK: Custom Functions
    private func configureUI(){
        registerCell(identifier: "TaskTableViewCell")
        btnLogout.layer.cornerRadius = 10
    }
    
    
    private func registerCell(identifier : String){
        let nib = UINib(nibName: identifier, bundle: nil)
        tblViewTasksList.register(nib, forCellReuseIdentifier: identifier)
    }
    
    private func gotoTaskDetailsVC(){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TaskDetailVC") as! TaskDetailVC
        vc.user = user
        self.navigationController?.pushViewController(vc, animated: true)
    }

    //MARK: IBActions
    @IBAction func btnActionAddTasks(_ sender: UIButton) {
        gotoTaskDetailsVC()
    }
    
    
    @IBAction func btnLogoutAction(_ sender: UIButton) {
        UserDefaults.standard.setValue(false, forKey: "isLogin")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnAddAction(_ sender: UIButton) {
        gotoTaskDetailsVC()
    }
    
}


extension TasksListVC : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TaskDetailVC") as! TaskDetailVC
        vc.user = user
        if tasks.count > 0 {
            vc.task = tasks[indexPath.row]
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
     func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
     func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let task = self.tasks[indexPath.row]
            TaskManager.shared.deleteTask(task: task)
            tasks = TaskManager.shared.fetchAllTasks(userid: user?.id ?? "")
            tableView.reloadData()
        }
    }
}

extension TasksListVC : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.tasks.count > 0 {
            self.btnAdd.isHidden = false
            self.tblViewTasksList.isHidden = false
            return tasks.count
        }
        self.tblViewTasksList.isHidden = true
        self.btnAdd.isHidden = true
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskTableViewCell", for: indexPath) as! TaskTableViewCell
        if self.tasks.count > 0 {
            cell.configCell(task: tasks[indexPath.row])
        }
        return cell
    }
}
