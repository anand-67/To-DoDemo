//
//  Date+Exyension.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
//

import Foundation


extension Date {
    func offsetFromForStreamDisplay(date : Date) -> String {
        let supportedComponents: Set<Calendar.Component> = [.day, .hour, .minute, .second]
        let offset = NSCalendar.current.dateComponents(supportedComponents, from: date, to: self);
        
        let seconds = "A moment ago"
        let minutes = "\(offset.minute ?? 0)m"
        let hours = "\(offset.hour ?? 0)h"
        let days = "\(offset.day ?? 0)d" + " " + hours
        
        if let day = offset.day, day          > 0 { return days + " ago" }
        if let hour = offset.hour, hour       > 0 { return hours + " ago" }
        if let minute = offset.minute, minute > 0 { return minutes + " ago" }
        if let second = offset.second, second > 0 { return seconds }
        return ""
    }
    
    func format(format : String) -> String {
        let dateFormater = DateFormatter()
        dateFormater.dateFormat = format
        return dateFormater.string(from: self)
    }
}
