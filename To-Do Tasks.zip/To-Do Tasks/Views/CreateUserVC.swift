//
//  CreateUserVC.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 29/11/24.
//

import UIKit
import CoreData

class CreateUserVC: UIViewController {
    
    //MARK: UITextFields
    @IBOutlet weak var txtFieldUserId: UITextField!
    @IBOutlet weak var txtFieldPassword: UITextField!
    @IBOutlet weak var txtFieldConfirmPassword: UITextField!
    
    //MARK: UIButtons
    @IBOutlet weak var btnCreateAccount: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addRecognizer()
        confifureUI()
    }
    
    private func confifureUI(){
        btnCreateAccount.layer.cornerRadius = 10
        let textFields = [txtFieldPassword , txtFieldUserId , txtFieldConfirmPassword]
        for field in textFields {
            field?.layer.borderWidth = 1
            field?.layer.cornerRadius = 10
            field?.layer.borderColor = UIColor.white.cgColor
            field?.textColor = .white
            field?.setLeftPaddingPoints(10)
        }
    }
    
    private func addRecognizer(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboardOnTouch))
        self.view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboardOnTouch() {
        self.view.endEditing(true)
    }
    

    //MARK: Custom function
    func register() {
        guard let username = txtFieldUserId.text, let password = txtFieldPassword.text else {
            return
        }
        
        CoreaDataManager.shared.saveUser(username: username, password: password)
    }
    
    
    
    //MARK: @IBActions
    @IBAction func btnCreateAccountAction(_ sender: UIButton) {
       register()
    }
    

}
