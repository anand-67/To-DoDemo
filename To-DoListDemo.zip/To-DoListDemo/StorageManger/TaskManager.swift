import Foundation
import CoreData

class TaskManager {
    
    // MARK: - Singleton
    static let shared = TaskManager()
    
    private init() {} // Private initializer to enforce singleton pattern
    
    // Get the managed object context
    private var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    // MARK: - Core Data Stack
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "To_DoListDemo")
        container.loadPersistentStores { description, error in
            if let error = error {
                fatalError("Failed to load Core Data stack: \(error.localizedDescription)")
            }
        }
        return container
    }()
    
    // MARK: - CRUD Operations
    
    // Create a new task for a user using their username
    // Create a new task
    func createTask(username: String, title: String, description: String, dueDate: Date, priority: String, isComplete: Bool, context: NSManagedObjectContext? = nil) {
        let context = context ?? self.context
        
        if let user = UserManager.shared.fetchUser(username: username) {
            // Create a new task entity
            let taskEntity = NSEntityDescription.entity(forEntityName: "Task", in: context)!
            let task = NSManagedObject(entity: taskEntity, insertInto: context) as! Task
            
            // Set task properties
            task.title = title
            task.taskDescription = description
            task.dueDate = dueDate
            task.priority = priority
            task.isComplete = isComplete
            task.userId = user.id
            
            saveContext(context: context)
        } else {
            print("User not found")
        }
    }



    // Update a task's details for a user
    func updateTask(task: Task, newTitle: String, newDescription: String, newDueDate: Date, newPriority: String, isComplete: Bool, context: NSManagedObjectContext? = nil) {
        let context = context ?? self.context
        
        task.title = newTitle
        task.taskDescription = newDescription
        task.dueDate = newDueDate
        task.priority = newPriority
        task.isComplete = isComplete
        
        saveContext(context: context)
    }

    // Delete a task for a user
    func deleteTask(task: Task, context: NSManagedObjectContext? = nil) {
        let context = context ?? self.context
        context.delete(task)
        saveContext(context: context)
    }

    
    // Fetch all tasks for a specific user
    func fetchAllTasks(userid: String, context: NSManagedObjectContext? = nil) -> [Task] {
        let context = context ?? self.context
        let fetchRequest: NSFetchRequest<Task> = Task.fetchRequest()
        do {
            let tasks = try context.fetch(fetchRequest)
            return tasks.filter {$0.userId == userid}
        } catch {
            print("Failed to fetch tasks: \(error.localizedDescription)")
            return []
        }
    }
    
    // MARK: - Core Data Saving Support
    private func saveContext(context: NSManagedObjectContext) {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                print("Failed to save context: \(error.localizedDescription)")
            }
        }
    }
}


