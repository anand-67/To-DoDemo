//
//  CoreaDataManager.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
//

import Foundation
import CryptoKit
import CoreData
import UIKit


class CoreaDataManager {
    
    static let shared = CoreaDataManager()
    
    private init() {}
    
    
    func hashPassword(_ password: String) -> String {
        let passwordData = Data(password.utf8)
        let hash = SHA256.hash(data: passwordData)
        return hash.map { String(format: "%02x", $0) }.joined()
    }
    
    func saveUser(username: String, password: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        let userEntity = NSEntityDescription.entity(forEntityName: "User", in: context)!
        let user = NSManagedObject(entity: userEntity, insertInto: context)
        
        user.setValue(username, forKey: "username")
        user.setValue(hashPassword(password), forKey: "passwordHash")
        
        do {
            try context.save()
        } catch {
            print("Failed to save user data: \(error.localizedDescription)")
        }
    }
    
    func verifyUser(username: String, password: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return false}
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "username == %@", username)
        
        do {
            let users = try context.fetch(fetchRequest)
            
            if let user = users.first {
                let storedHash = user.passwordHash
                return storedHash == hashPassword(password)
            }
        } catch {
            print("Failed to fetch user data: \(error.localizedDescription)")
        }
        
        return false
    }
    
}
