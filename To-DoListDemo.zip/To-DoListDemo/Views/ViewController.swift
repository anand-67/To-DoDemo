//
//  ViewController.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 29/11/24.
//

import UIKit
import CoreData


class ViewController: UIViewController {
    
    
    //MARK: UITextFields
    @IBOutlet weak var txtFieldUserId: UITextField!
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    
    //MARK: UIButtons
    @IBOutlet weak var btnSignup: UIButton!
    @IBOutlet weak var btnLogin: UIButton!
    

    //MARK: Variables
    var context: NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let isLoggedIn = UserDefaults.standard.value(forKey: "isLogin") as? Bool , isLoggedIn{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "TasksListVC") as! TasksListVC
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            configureUI()
            addRecognizer()
        }
    }
    
    //MARK: Custom Functions
    private func configureUI(){
        btnLogin.layer.cornerRadius = 10
        txtFieldPassword.layer.borderWidth = 1
        txtFieldUserId.layer.borderWidth = 1
        txtFieldPassword.layer.cornerRadius = 10
        txtFieldUserId.layer.cornerRadius = 10
        txtFieldPassword.layer.borderColor = UIColor.white.cgColor
        txtFieldUserId.layer.borderColor = UIColor.white.cgColor
        txtFieldPassword.textColor = .white
        txtFieldUserId.textColor = .white
        txtFieldPassword.setLeftPaddingPoints(10)
        txtFieldUserId.setLeftPaddingPoints(10)
    }
    
    private func addRecognizer(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboardOnTouch))
        self.view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboardOnTouch() {
        self.view.endEditing(true)
    }
    
    
    func login() -> Bool {
        guard let username = txtFieldUserId.text, let password = txtFieldPassword.text else {
            return false
        }
        
        let isValid = UserManager.shared.verifyUser(username: username, password: password)
        
        if isValid {
            return true
        }
        
        UserDefaults.standard.setValue(username, forKey: "username")
        
        return false
    }
    
    
    //MARK: UIButtonActions
    @IBAction func btnSignupAction(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "CreateUserVC") as! CreateUserVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func btnLoginAction(_ sender: UIButton) {
        if login(){
            UserDefaults.standard.setValue(true, forKey: "isLogin")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "TasksListVC") as! TasksListVC
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            showToast(message: "User Does not exists", font: .systemFont(ofSize: 12), bottom: 250)
        }
    }
    

}

