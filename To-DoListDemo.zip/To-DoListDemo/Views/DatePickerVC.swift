//
//  DatePickerVC.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
//

import UIKit

protocol DateSelectorDelegate {
    func selectedDate(date : Date)
}

class DatePickerVC: UIViewController {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var btnStackView: UIStackView!
    @IBOutlet weak var btnSelect: UIButton!
    @IBOutlet weak var nsLayoutDatePickerHeightConstraint: NSLayoutConstraint!
    
    var datePickerMode : UIDatePicker.Mode?
    var viewController : String?
    var dateSelecteDelegate : DateSelectorDelegate?
    var isMonthlyType : Bool?
    var maxDate : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let mode = self.datePickerMode{
            //self.setupDatePicker(mode: mode)
        }
        addRecognizer()

        self.restrictCalendar(minDate: true, maxDate: false, days: nil, months: nil, years: nil)
    }
    
    
    private func addRecognizer(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboardOnTouch))
        self.backView.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboardOnTouch() {
        self.dismiss(animated: true)
    }
    
    func restrictCalendar(minDate : Bool? , maxDate : Bool? , days : Int? , months : Int? , years : Int?){
        
        let date = Date()
        let calendar = Calendar(identifier: .gregorian)
        var components = DateComponents()
        components.calendar = calendar
        
        if let min = minDate , let max = maxDate{
            if (min && max){
                if let isMonthlyType = isMonthlyType {
                    if isMonthlyType{
                        components.day = days
                        let maxDateForMeet = calendar.date(byAdding: components, to: date)!
                        datePicker.maximumDate = maxDateForMeet
                        components.day = 1
                        let nextDayForMonthly = calendar.date(byAdding: components, to: date)!
                        datePicker.minimumDate = nextDayForMonthly
                    }else{
                        components.day = days
                        let maxDateForMeet = calendar.date(byAdding: components, to: date)!
                        datePicker.maximumDate = maxDateForMeet
                        datePicker.minimumDate = date
                    }
                }
            }else if (min && !max){
                datePicker.minimumDate = date
            }else if (!min && max){
                components.year = -16
                let maxYearForDob = calendar.date(byAdding: components, to: date)
                datePicker.maximumDate = maxYearForDob
            }
        }
    }
    
    
    
    func setupDatePicker(mode : UIDatePicker.Mode){
        datePicker.datePickerMode = mode
        datePicker.layer.cornerRadius = 10
        datePicker.layer.masksToBounds = true
        datePicker.backgroundColor = .white
    }
    
    
    @IBAction func btnSelectAction(_ sender: UIButton) {
        self.dateSelecteDelegate?.selectedDate(date: datePicker.date)
        self.dismiss(animated: true)
    }
    
    @IBAction func btnCancelAction(_ sender: UIButton) {
        self.dismiss(animated: true)
    }

}
