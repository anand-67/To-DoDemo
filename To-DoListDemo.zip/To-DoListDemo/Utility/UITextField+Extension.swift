//
//  UITextField+Extension.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 29/11/24.
//

import Foundation
import UIKit



extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
}
