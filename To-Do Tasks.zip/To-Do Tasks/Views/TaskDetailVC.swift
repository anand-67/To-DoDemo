//
//  TaskDetailVC.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
//

import UIKit

enum Priority : String{
    case High = "High"
    case Medium = "Medium"
    case Low = "Low"
}

class TaskDetailVC: UIViewController {

    
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var txtViewDescription: UITextView!
    @IBOutlet weak var txtViewTitle: UITextView!
    @IBOutlet weak var imgViewStatus: UIImageView!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblPriority: UILabel!
    @IBOutlet weak var viewPriorityColour: UIView!
    @IBOutlet weak var viewLow: UIView!
    @IBOutlet weak var viewMedium: UIView!
    @IBOutlet weak var stkViewPriority: UIStackView!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var viewHigh: UIView!
    
    
    var priority : Priority = .High
    var date : Date?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
        addRecognizer()
    }
    
    private func configUI(){
        txtViewTitle.delegate = self
        txtViewDescription.delegate = self
        txtViewTitle.textColor = UIColor.gray
        txtViewDescription.textColor = UIColor.gray
        btnSave.layer.cornerRadius = 10
        let views = [viewLow , viewHigh, viewMedium , viewPriorityColour]
        for view in views{
            view?.layer.cornerRadius = 18/2
        }
        
        self.lblDate.text = Date().format(format: "dd MMM YYYY")
    }
    
    private func addRecognizer(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboardOnTouch))
        self.view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboardOnTouch() {
        self.view.endEditing(true)
        
        if txtViewTitle.text == ""{
            txtViewTitle.textColor = UIColor.gray
            txtViewTitle.text = "Title"
        }
        
        if txtViewDescription.text == ""{
            txtViewDescription.textColor = UIColor.gray
            txtViewDescription.text = "Description"
        }
    }
    
    @IBAction func btnEditAction(_ sender: UIButton) {
        
        
    }
    
    
    @IBAction func btnSaveAction(_ sender: UIButton) {
        TaskManager.shared.createTask(title: txtViewTitle.text, description: txtViewDescription.text, dueDate: self.date ?? Date(), priority: self.lblPriority.text ?? "High")
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnDateAction(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DatePickerVC") as! DatePickerVC
        vc.dateSelecteDelegate = self
        vc.datePickerMode = .date
        self.navigationController?.present(vc, animated: true)
    }
    
    @IBAction func btnTaskStatusAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected{
            imgViewStatus.image = UIImage(named: "check")
            lblStatus.text = "Completed"
        }else{
            imgViewStatus.image = UIImage(named: "Ellipse")
            lblStatus.text = "Incomplete"
        }
    }
    
    
    @IBAction func btnTaskPriorityAction(_ sender: UIButton) {
        self.stkViewPriority.isHidden = false
    }
    
    @IBAction func btnHighAction(_ sender: UIButton) {
        self.stkViewPriority.isHidden = true
        self.priority = .High
        self.viewPriorityColour.backgroundColor = .red
        self.lblPriority.text = "High"
        self.lblPriority.textColor = .red
        
    }
    
    @IBAction func btnMediumAction(_ sender: UIButton) {
        self.stkViewPriority.isHidden = true
        self.priority = .Medium
        self.viewPriorityColour.backgroundColor = .yellow
        self.lblPriority.text = "Medium"
        self.lblPriority.textColor = .yellow
        
    }
    
    @IBAction func btnLowAction(_ sender: UIButton) {
        self.stkViewPriority.isHidden = true
        self.priority = .Low
        self.viewPriorityColour.backgroundColor = .green
        self.lblPriority.text = "Low"
        self.lblPriority.textColor = .green
    }
}



extension TaskDetailVC : UITextViewDelegate{
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.gray {
            textView.text = nil
            textView.textColor = UIColor.white
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView == txtViewTitle.textContainer && textView.text == ""{
            textView.textColor = UIColor.gray
            textView.text = "Title"
        }
        
        if textView == txtViewDescription.textContainer && textView.text == ""{
            textView.textColor = UIColor.gray
            textView.text = "Description"
        }
    }
}

extension TaskDetailVC : DateSelectorDelegate{
    func selectedDate(date: Date) {
        self.date = date
        self.lblDate.text = date.format(format: "dd MMM YYYY")
    }
}
