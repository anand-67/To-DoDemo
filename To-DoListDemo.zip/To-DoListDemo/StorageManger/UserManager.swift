//
//  CoreaDataManager.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
//

import Foundation
import CryptoKit
import CoreData
import UIKit

class UserManager {
    
    static let shared = UserManager()
    
    private init() {}
    
    func hashPassword(_ password: String) -> String {
        let passwordData = Data(password.utf8)
        let hash = SHA256.hash(data: passwordData)
        return hash.map { String(format: "%02x", $0) }.joined()
    }
    
    func saveUser(username: String, password: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        let userEntity = NSEntityDescription.entity(forEntityName: "User", in: context)!
        let user = NSManagedObject(entity: userEntity, insertInto: context)
        
        user.setValue(username, forKey: "username")
        user.setValue(hashPassword(password), forKey: "passwordHash")
        user.setValue(randomString(length: 10), forKey: "id")
        
        do {
            try context.save()
        } catch {
            print("Failed to save user data: \(error.localizedDescription)")
        }
    }
    
    func verifyUser(username: String, password: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return false}
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "username == %@", username)
        
        do {
            let users = try context.fetch(fetchRequest)
            
            if let user = users.first {
                let storedHash = user.passwordHash
                return storedHash == hashPassword(password)
            }
        } catch {
            print("Failed to fetch user data: \(error.localizedDescription)")
        }
        
        return false
    }
    
    func doesUserExist(username: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return false }
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "username == %@", username)
        
        do {
            let users = try context.fetch(fetchRequest)
            return users.count > 0
        } catch {
            print("Failed to fetch user data: \(error.localizedDescription)")
            return false
        }
    }
    
    func fetchUser(username: String) -> User? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return nil }
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "username == %@", username)
        
        do {
            let users = try context.fetch(fetchRequest)
            return users.first
        } catch {
            print("Failed to fetch user data: \(error.localizedDescription)")
            return nil
        }
    }
    
    func randomString(length: Int) -> String {
      let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
      return String((0..<length).map{ _ in letters.randomElement()! })
    }
}

