//
//  TaskManager.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
import Foundation
import CoreData

class TaskManager {
    
    // MARK: - Singleton
    static let shared = TaskManager()
    
    private init() {} // Private initializer to enforce singleton pattern
    
    // Get the managed object context
    private var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    // MARK: - Core Data Stack
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "TaskManagerModel") // Use your Core Data model name here
        container.loadPersistentStores { description, error in
            if let error = error {
                fatalError("Failed to load Core Data stack: \(error.localizedDescription)")
            }
        }
        return container
    }()
    
    // MARK: - CRUD Operations

    // Create a new task
    func createTask(title: String, description: String, dueDate: Date, priority: String, context: NSManagedObjectContext? = nil) {
        let context = context ?? self.context
        let taskEntity = NSEntityDescription.entity(forEntityName: "TaskManagerModel", in: context)!
        let task = NSManagedObject(entity: taskEntity, insertInto: context)
        
        task.setValue(title, forKey: "title")
        task.setValue(description, forKey: "taskDescription")
        task.setValue(dueDate, forKey: "dueDate")
        task.setValue(priority, forKey: "priority")
        task.setValue(false, forKey: "isComplete")  // Default to incomplete
        
        saveContext(context: context)
    }

    // Update task completion status
    func updateTaskCompletion(task: TaskManagerModel, isComplete: Bool, context: NSManagedObjectContext? = nil) {
        let context = context ?? self.context
        task.isComplete = isComplete
        saveContext(context: context)
    }

    // Update a task (e.g., title, description, etc.)
    func updateTask(task: TaskManagerModel, newTitle: String, newDescription: String, newDueDate: Date, newPriority: String, context: NSManagedObjectContext? = nil) {
        let context = context ?? self.context
        task.title = newTitle
        task.taskDescription = newDescription
        task.dueDate = newDueDate
        task.priority = newPriority
        saveContext(context: context)
    }

    // Delete a task
    func deleteTask(task: TaskManagerModel, context: NSManagedObjectContext? = nil) {
        let context = context ?? self.context
        context.delete(task)
        saveContext(context: context)
    }

    // Fetch tasks by completion status
    func fetchTasks(isComplete: Bool, context: NSManagedObjectContext? = nil) -> [TaskManagerModel]? {
        let context = context ?? self.context
        let fetchRequest: NSFetchRequest<TaskManagerModel> = TaskManagerModel.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "isComplete == %d", isComplete)
        
        do {
            let tasks = try context.fetch(fetchRequest)
            return tasks
        } catch {
            print("Failed to fetch tasks: \(error.localizedDescription)")
            return nil
        }
    }
    
    // Fetch all tasks
    func fetchAllTasks(context: NSManagedObjectContext? = nil) -> [TaskManagerModel]? {
        let context = context ?? self.context
        let fetchRequest: NSFetchRequest<TaskManagerModel> = TaskManagerModel.fetchRequest()
        
        do {
            let tasks = try context.fetch(fetchRequest)
            return tasks
        } catch {
            print("Failed to fetch tasks: \(error.localizedDescription)")
            return nil
        }
    }
    
    // MARK: - Core Data Saving Support
    private func saveContext(context: NSManagedObjectContext) {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                print("Failed to save context: \(error.localizedDescription)")
            }
        }
    }
}

