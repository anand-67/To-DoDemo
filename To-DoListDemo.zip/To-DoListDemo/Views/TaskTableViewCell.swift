//
//  TaskTableViewCell.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
//

import UIKit

class TaskTableViewCell: UITableViewCell {
    
    //MARK: UILabel
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblPriority: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    
    //MARK: UIButton
    @IBOutlet weak var btnTaskStatus: UIButton!
    
    //MARK: UIView
    @IBOutlet weak var viewContent: UIView!
    @IBOutlet weak var viewPriority: UIView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
//        viewContent.layer.cornerRadius = 10
//        viewContent.layer.borderColor = UIColor.white.cgColor
//        viewContent.layer.borderWidth = 0.8
        viewPriority.layer.cornerRadius = 10
    }
    
    func configCell(task : Task){
        lblTitle.text = task.title
        lblPriority.text = task.priority
        lblDescription.text = task.taskDescription
        lblDate.text = task.dueDate?.format(format: "dd MMM YYYY")
        
        if task.isComplete{
            btnTaskStatus.setImage(UIImage(named: "check"), for: .normal)
        }else{
            btnTaskStatus.setImage(UIImage(named: "Ellipse"), for: .normal)
        }
        
        switch task.priority{
        case "High":
            viewPriority.backgroundColor = .red
            lblPriority.textColor = .red
        case "Medium":
            viewPriority.backgroundColor = .yellow
            lblPriority.textColor = .yellow
        case "Low":
            viewPriority.backgroundColor = .green
            lblPriority.textColor = .green
        default:
            break
        }
    }
    
    
    @IBAction func btnTaskStatusAction(_ sender: UIButton) {
        
    }
    
    
    
}
