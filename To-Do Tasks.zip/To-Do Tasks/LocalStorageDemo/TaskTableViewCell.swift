//
//  TaskTableViewCell.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
//

import UIKit

class TaskTableViewCell: UITableViewCell {
    
    //MARK: UILabel
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblPriority: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    
    //MARK: UIButton
    @IBOutlet weak var btnTaskStatus: UIButton!
    
    //MARK: UIView
    @IBOutlet weak var viewPriority: UIView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configCell(task : TaskManagerModel){
        lblTitle.text = task.title
        lblPriority.text = task.priority
        lblDescription.text = task.description
        lblDate.text = task.dueDate?.format(format: "dd MMM YYYY")
        
        if task.isComplete{
            btnTaskStatus.setImage(UIImage(named: "check"), for: .normal)
        }else{
            btnTaskStatus.setImage(UIImage(named: "Ellipse"), for: .normal)
        }
    }
    
    
    @IBAction func btnTaskStatusAction(_ sender: UIButton) {
        
    }
    
    
    
}
