//
//  TasksListVC.swift
//  LocalStorageDemo
//
//  Created by Anand S Koti on 30/11/24.
//

import UIKit

class TasksListVC: UIViewController {

    
    //MARK: UITableView
    @IBOutlet weak var tblViewTasksList: UITableView!
    
    //MARK: UIButton
    @IBOutlet weak var btnAddTasks: UIButton!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCell(identifier: "TaskTableViewCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tblViewTasksList.reloadData()
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    
    //MARK: Custom Functions
    private func registerCell(identifier : String){
        let nib = UINib(nibName: identifier, bundle: nil)
        tblViewTasksList.register(nib, forCellReuseIdentifier: identifier)
    }

    //MARK: IBActions
    @IBAction func btnActionAddTasks(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TaskDetailVC") as! TaskDetailVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}


extension TasksListVC : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

extension TasksListVC : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let allTasks = TaskManager.shared.fetchAllTasks() {
            if allTasks.count > 0 {
                return allTasks.count
            }
        }
        self.tblViewTasksList.isHidden = true
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskTableViewCell", for: indexPath) as! TaskTableViewCell
        if let allTasks = TaskManager.shared.fetchAllTasks() {
            if allTasks.count > 0 {
                cell.configCell(task: allTasks[indexPath.row])
            }
        }
        return cell
    }
    
    
}
